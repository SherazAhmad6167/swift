/*var environment = "development"
let loginAttempts : Int
if environment != "development" {
    loginAttempts = 100
}else{
    loginAttempts = 10
}*/

//let a = "cat" ; print(a)

//      boolean         //
/*let orangesAreOrange = false
if orangesAreOrange {
    print("orange")
}else{
    print("yellow")
}*/

//      tuple           // multiple values of different data types in one compound value
/*let httpp404 = (404, "Not Found")
let(statusCode, statusMessage ) = httpp404
print("statusCode is ",(statusCode))
print("statusMessage is",(statusMessage))*/

//              optionals  :   may have value or not, ? is used
/*let Number = "abc"
let convertedNumber = Int(Number)
if convertedNumber != nil{
    print("converted Number have integar values")
}
//          opttional binding ma chheck krta hhn koi value ha k ni
var name : String?
name = "sheraz"
name = nil
if let actualName = name{
    print("Name is", actualName)
}else{
    print("nil")
}*/

//      Error Handling          //
/*func makeASandwich() throws {
}
    do{
        try makeASandwich()
        eatASandwich()
    }
catch SandwichError.outOfCleanDishes{
    washDishes()
}
catch SandwichError.makeIngrediant(let ingrediant){
    buyGroceries()
}*/

//enum SandwichError: Error{
//    case outOfCleanDishes
//    case makeIngredient(ingredient: String)
//}
//
//func makeASandwich() throws {
//    let cleanDishesAvialable = false
//    if !cleanDishesAvialable {
//        throw SandwichError.outOfCleanDishes
//    }
//    let ingrediantAvailable = false
//    if !ingrediantAvailable {
//        throw SandwichError.makeIngredient(ingredient: "chicken")
//    }
//    print("sandwich is made")
//}
//do{
//    try makeASandwich()
//    print("eating a sandwich")
//}
//catch SandwichError.outOfCleanDishes{
//    print("dishes are not avaiable")
//}
//catch SandwichError.makeIngredient(let ingredient){
//    print("iingediiant is not available")
//}
//catch{
//    print("unknown error")
//}

//          assertion           //
/*let number = 5
precondition(number > 0,"Number should be positive")
assert(number > 0, "Number should be positive")*/

//          for loop        //
/*let noOfLegs = ["spider":8, "ant":4]
for (AnimalName , legs) in noOfLegs{
    print((AnimalName), "have" ,(legs))
}

for i in 1...5 {
    print("sheraz \(i)")
}*/

/*let number = 60
for num in 1..<number{
    print(num)
}*/

//      while           //
/*var a=1
var b=10
while(a<=b){
    print(a)
    a+=1
}*/
/*var a=1
var b=5
repeat{
    print(a)
    a+=2
}while(a>=b)*/


//          array           //
/*var arr : [Int] = [1,2,3,4,5,6]
var obj = ["a":1,"b":2]
for y in obj{
    print(y)
}
print(arr[3])
for i in 2..<arr.count{
    print(i)
}*/

/*var arr : [[Int]] = [[1,2,4],[1,2,5],[1,2,6]]
//print(arr[0][2])
for i in 0...2{
    for j in 0...2{
        print(arr[i][j])
    }
}*/

//          set             //
/*var number : Set<Int> = [1,2,3,4,5,5,2,6]
number.insert(11)
number.remove(1)

if number.contains(4){
    print("have element")
}else{
    print("doesnot have element")
}
print(number)*/

//

//          switch statement            // fallthrough moves to all cases, break : print correct case and out of tthe switch
//                                 continuue:  used iiin loop , stop that itereation in thhat case and agaiin loop start
/*let a = 2
let b = 5
switch (a){
case 1:
    print("alpha")
case 2:
    print("bravo")
case 3:
    if b == 5{
        print("django")
    }else{
        print("charlie")
    }
    
default:
    print("not found")
}*/


//                  object:dictionary           //
/*var dic : [String:Int] = ["a":1, "b":2, "c":3]
print(dic.isEmpty)
print(dic.count)
if let val = dic.updateValue(4, forKey: "d"){
    print("value is \(val)")
}
if let value =  dic.removeValue(forKey: "a"){
    print("value is \(value)")
}
for (key,value) in dic{
    print((key),"have",(value) )
}*/


//              function            //

/*func info(name: String , age: Int){
    print("name is \(name) and age is \(age)")
}
info(name: "sheraz" , age: 20)

func add(a:Int,b:Int)-> Int{
    return a+b
}
print(add(a:3,b:4))
// when using return type, call with print
func total()->Int{
    return 10
}
print(total())


func parent(name: String){
    func child(){
        print("my name is \(name)")
    }
    child()
}
parent(name: "sheraz")

//              recursion function                  //
func number(num : Int){
    print(num)
    if(num<10){
        number(num:num + 1)
    }
}
number(num: 1)*/

//              closure                 //

/*let name : (String)->(String) =
{
    app in let value = "Name is \(app)"
    return value
}
print(name("sheraz"))*/
