import UIKit

var greeting = "Hello, playground"

/*func generic<T> (a: T) -> T.Type{
    //print(type(of : a))
    return type(of: a)
}
let b = "asd"
print(generic(a: b))*/



/*var name:String?
name = "sheraz"
 
print("name is \(name ?? "ali")")*/


//              Array                       //
/*var arr : [Int] = [1,2]
arr.append(4)
arr.append(5)
arr += [6]
print(arr)
print(arr[3])
arr[0] = 8
arr.insert(10, at: 1)
print(arr)
arr.remove(at: 5)
arr.removeLast()
print(arr)
for item in arr{
    print(item)
}
var arr1 = ["a","b","c","d","e"]
for (index, value) in arr1.enumerated(){
    print("\(index): \(value)")
}*/

//              Set                 //
/*var names : Set = ["ali","ahmad","hasan","afaq"]
names.insert("sheraz")
if names.contains("ali"){
    print("have a name")
}else{
    print("not")
}
print(names)
for items in names.sorted(){
    print(items)
}*/

//              Dictionary              //
/*var dic = [1 : "a" ,2 : "b",3 : "c"]
print(dic.count)
//print(dic.updateValue("a", forKey: 1))
if let dictionary = dic.updateValue("b", forKey: 4){
    print("value is \(dictionary)")
}
if let dictionary = dic.removeValue(forKey: 1){
    print("value is \(dictionary)")
}

for (dicCode, dicValue) in dic {
    print("\(dicCode) : \(dicValue)")
}*/

//              for             //
/*var number = [1,2,3,4,5,6,7,8]
for item in 1...5{
    print(item)
}
for item in 1..<4{
    print(item)
}*/

// defer: call after the function execute       //
//  inout :
//              closures:          //

//let add:(Int,Int) -> Int = {(a,b) in return a+b }
//let result = add(4,6)
//print(result)

//            property      //
//Stored Properties: wo properties hoti hain jo class/structure ke andar value ko directly store karti hain.
//Computed Properties: wo properties hain jo kisi aur property ke basis par value ko calculate karti hain. create func
//Lazy Properties: wo properties hain jo pehli baar access karne par initialize hoti hain.
//Property Observers: aapko allow karte hain ke jab property ki value change ho to aap kuch actions perform kar sakein.
// willset: before change, didset: after change
// lazy:  The someString property is initialized only when it is accessed for the first time. it is not acccessed seconddd time


/*class Example {
    lazy var someString: String = {
        print("Initializing property")
        return "Hello, Swift!"
    }()
}

let obj = Example()
print("Before accessing lazy property")
print(obj.someString)       //   print only first time
print(obj.someString)
print(obj.someString)
print("After accessing lazy property")*/

/*struct TimesTable {
    var multiplier: Int
    subscript(index: Int) -> Int{
        return multiplier * index
    }
}

let tableOfFive = TimesTable(multiplier: 5)
print(tableOfFive[3])     // subscript define in []
print(tableOfFive[10])*/

